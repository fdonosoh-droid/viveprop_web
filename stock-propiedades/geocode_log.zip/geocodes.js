// Auto-generado por geocode_all.py — no editar manualmente
// Entradas: 322 | Nulas: 18
const GEOCODES = {
  "General Saavedra 1247|Independencia": [
    -33.40913,
    -70.655505
  ],
  "Av. Goycolea 720|La Cisterna": [
    -33.537465,
    -70.674466
  ],
  "Amalia Errázuriz 956|Independencia": [
    -33.419998,
    -70.657233
  ],
  "Aníbal Pinto 1270|Independencia": [
    -33.427079,
    -70.655396
  ],
  "Concón 165|Estación Central": [
    -33.453072,
    -70.696468
  ],
  "Fray Camilo Henríquez 320|Santiago": [
    -33.446102,
    -70.634878
  ],
  "Carvajal 0358|La Cisterna": [
    -33.516392,
    -70.660659
  ],
  "Toro Mazote 64|Estación Central": [
    -33.47065,
    -70.690456
  ],
  "Llanquihue 6290|La Florida": [
    -33.514169,
    -70.610542
  ],
  "Nicasio Retamales 115|Estación Central": [
    -33.455172,
    -70.688838
  ],
  "Gaspar de Orense 897|Quinta Normal": [
    -33.442525,
    -70.700059
  ],
  "General Mackenna 1490|Santiago": [
    -33.433184,
    -70.654488
  ],
  "Coquimbo 777|Santiago": [
    -33.456392,
    -70.646758
  ],
  "Av. Diego Portales 817|La Florida": [
    -33.562517,
    -70.576928
  ],
  "Av Libertador Bernardo O'Higgins 4103|Estación Central": [
    -33.453686,
    -70.692582
  ],
  "Conde del Maule 4106|Estación Central": [
    -33.453339,
    -70.692723
  ],
  "Av. Almte. Blanco Encalada 2527|Santiago": null,
  "Av. Irarrázaval 5485|Ñuñoa": [
    -33.453533,
    -70.610085
  ],
  "Conde del Maule 4470|Estación Central": [
    -33.45426,
    -70.696739
  ],
  "Av. Padre Alberto Hurtado 145|Estación Central": [
    -33.461345,
    -70.68259
  ],
  "Hipódromo Chile 1608|Independencia": [
    -33.407042,
    -70.662741
  ],
  "Lia Aguirre 95|La Florida": [
    -33.522842,
    -70.602101
  ],
  "Rivera 1370|Independencia": [
    -33.425721,
    -70.655928
  ],
  "Coronel Souper 4060|Estación Central": [
    -33.457594,
    -70.690533
  ],
  "Montau 1509|Independencia": [
    -33.403815,
    -70.662015
  ],
  "Chiloé 1951|Santiago": [
    -33.471713,
    -70.645341
  ],
  "Inglaterra 1144|Independencia": [
    -33.41247,
    -70.65522
  ],
  "Av. Sta. Rosa 5740|San Miguel": [
    -33.477101,
    -70.642669
  ],
  "Pintor Cicarelli 278|San Joaquín": [
    -33.47683,
    -70.635735
  ],
  "Juan De Barros 3885|Quinta Normal": [
    -33.431414,
    -70.685782
  ],
  "Santa Clara 360|La Cisterna": [
    -33.520314,
    -70.655404
  ],
  "Toro Mazotte 110|Estación Central": [
    -33.456122,
    -70.691206
  ],
  "Chacabuco 1120|Santiago": [
    -33.432519,
    -70.67967
  ],
  "Radal 0102|Estación Central": [
    -33.455196,
    -70.701629
  ],
  "Pablo Urzúa 1481|Independencia": [
    -33.40062,
    -70.661443
  ],
  "Córdova y Figueroa 1144|Quinta Normal": [
    -33.432811,
    -70.693527
  ],
  "Cruz 1275|Independencia": [
    -33.42454,
    -70.657264
  ],
  "Av. Sta. Rosa 5741|San Miguel": [
    -33.477101,
    -70.642669
  ],
  "Av. Santa Rosa 2648|San Joaquín": [
    -33.47978,
    -70.641528
  ],
  "Gral. González Balcarce 2041|Santiago": null,
  "Av. Inglaterra 1280|Independencia": [
    -33.412461,
    -70.657262
  ],
  "Av. Manuel Montt 2515|Ñuñoa": [
    -33.450722,
    -70.613188
  ],
  "Av. Almte Blanco Encalada 2527|Santiago": null,
  "Avenida Vicuña Mackenna 1207|Santiago": [
    -33.457195,
    -70.629604
  ],
  "Sta. Corina 100|La Cisterna": [
    -33.515038,
    -70.659687
  ],
  "Independencia 1815|Independencia": [
    -33.402034,
    -70.665141
  ],
  "Los Carrera 1131|Copiapó": null,
  "Coronel Souper 4158|Estación Central": [
    -33.457571,
    -70.691919
  ],
  "Av. Sta. Rosa 5739|San Miguel": [
    -33.477101,
    -70.642669
  ],
  "El Molino 1787|Independencia": [
    -33.418284,
    -70.665576
  ],
  "Av. Portales 672|San Bernardo": [
    -33.596227,
    -70.698448
  ],
  "San Martin 841|Santiago": [
    -33.4337,
    -70.65874
  ],
  "Toro Mazote 76|Estación Central": [
    -33.47065,
    -70.690456
  ],
  "Fernandez Albano 492|La Cisterna": [
    -33.524968,
    -70.652817
  ],
  "Av. Ecuador 4578|Estación Central": [
    -33.453776,
    -70.699088
  ],
  "Av. Pedro Nolasco Videla 810|Coquimbo": null,
  "Argomedo 65|Santiago": [
    -33.448996,
    -70.632778
  ],
  "Mac Iver 524|Santiago": [
    -33.436664,
    -70.647377
  ],
  "San Francisco 265|Santiago": [
    -33.44783,
    -70.647119
  ],
  "Cóndor 1107|Santiago": [
    -33.450408,
    -70.65038
  ],
  "Porto Seguro 4210|Estación Central": [
    -33.447788,
    -70.696179
  ],
  "Sta. Petronila 28|Estación Central": [
    -33.454284,
    -70.704864
  ],
  "Av. Rodrigo de Araya 2836|Ñuñoa": [
    -33.473771,
    -70.602249
  ],
  "Apóstol Santiago 32|Estación Central": [
    -33.451222,
    -70.693025
  ],
  "Antonio Ricaurte 317|Santiago": [
    -33.450664,
    -70.635413
  ],
  "Eleuterio Ramírez 1331|Santiago": [
    -33.449905,
    -70.653487
  ],
  "Matucana 1161|Santiago": [
    -33.44174,
    -70.679778
  ],
  "María Rozas Velásquez 55|Estación Central": [
    -33.454097,
    -70.705665
  ],
  "Santo Domingo 3905|Quinta Normal": [
    -33.438902,
    -70.688524
  ],
  "San Petersburgo 6351|San Miguel": [
    -33.515012,
    -70.647185
  ],
  "Av. Padre Alberto Hurtado 59|Estación Central": null,
  "Av. Independencia 740|Independencia": [
    -33.431486,
    -70.652877
  ],
  "Radal 66|Estación Central": [
    -33.453893,
    -70.701903
  ],
  "María Auxiliadora 721|San Miguel": [
    -33.488675,
    -70.645628
  ],
  "Santo Domingo 1161|Santiago": [
    -33.436161,
    -70.653686
  ],
  "Mensia de Los Nidos 1111|Santiago": [
    -33.450922,
    -70.651001
  ],
  "Villasana 1451|Quinta Normal": [
    -33.426173,
    -70.687523
  ],
  "Martinez de Rozas 3550|Quinta Normal": [
    -33.434807,
    -70.683215
  ],
  "Pje Titán 4870|Estación Central": null,
  "Mario Kreutzberger 1520|Santiago": [
    -33.435917,
    -70.658941
  ],
  "Diag. Sta. Elena 2605|San Joaquín": [
    -33.476112,
    -70.626958
  ],
  "Serrano 266|Santiago": [
    -33.44815,
    -70.648531
  ],
  "Av. Macul 2301|Macul": [
    -33.475575,
    -70.599005
  ],
  "Santa Elena 1760|Santiago": [
    -33.466972,
    -70.627928
  ],
  "Tarapaca 1331|Santiago": [
    -33.447673,
    -70.653474
  ],
  "Av. Sta. Rosa 5738|San Miguel": [
    -33.477101,
    -70.642669
  ],
  "Eleuterio Ramírez 1024|Santiago": [
    -33.449167,
    -70.6497
  ],
  "Conde del Maule 4364|Estación Central": [
    -33.454092,
    -70.695797
  ],
  "Av. Ecuador 3866|Estación Central": [
    -33.45127,
    -70.689582
  ],
  "Vicuña Mackenna 1725|Santiago": [
    -33.466406,
    -70.626939
  ],
  "Patricio Lynch 1650|Quinta Normal": [
    -33.433795,
    -70.681598
  ],
  "Mario Kreutzberger 1558|Santiago": [
    -33.435944,
    -70.659488
  ],
  "Santa Victoria 562|Santiago": [
    -33.449027,
    -70.642919
  ],
  "Cuarta Avenida 1350|San Miguel": [
    -33.506154,
    -70.661006
  ],
  "Hipódromo Chile 1876|Independencia": [
    -33.40665,
    -70.667078
  ],
  "Jose Manuel Balmaceda 3751 (Apostol) Torre-B|Renca": null,
  "Sgto. Aldea 1156|Santiago": null,
  "Curiñanca 715|San Miguel": [
    -33.490444,
    -70.641875
  ],
  "Vargas Buston 770|San Miguel": [
    -33.509056,
    -70.648564
  ],
  "Av. Ecuador 5079|Estación Central": [
    -33.454813,
    -70.703955
  ],
  "Colón 6479|La Cisterna": [
    -33.525349,
    -70.670699
  ],
  "Los Olmos 4587|Macul": [
    -33.48018,
    -70.583614
  ],
  "Sta. Elisa 490|La Cisterna": [
    -33.519627,
    -70.653588
  ],
  "Leonor Cepeda 952|Independencia": [
    -33.419824,
    -70.659839
  ],
  "Av. Américo Vespucio 4601|Macul": [
    -33.509347,
    -70.590515
  ],
  "General Gana 1063|Santiago": [
    -33.470907,
    -70.647837
  ],
  "Primera Avenida 1478|San Miguel": [
    -33.502799,
    -70.661804
  ],
  "San Diego 1499|Santiago": [
    -33.45302,
    -70.650193
  ],
  "Av. Manuel Rodríguez 881|Santiago": [
    -33.446245,
    -70.66074
  ],
  "Nueva Andres Bello 1890|Independencia": null,
  "Vicuña Mackenna 1751|Santiago": [
    -33.466693,
    -70.626857
  ],
  "El Molino 1755|Independencia": [
    -33.418203,
    -70.664555
  ],
  "Gaspar de Orense 828|Quinta Normal": [
    -33.443508,
    -70.700276
  ],
  "Briones Luco 0957|La Cisterna": [
    -33.515346,
    -70.661671
  ],
  "Zenteno 1490|Santiago": [
    -33.465929,
    -70.649754
  ],
  "San Martín 714|Santiago": [
    -33.435535,
    -70.658696
  ],
  "San Pablo 4025|Quinta Normal": [
    -33.437514,
    -70.689465
  ],
  "Placilla 149|Estación Central": [
    -33.457004,
    -70.69426
  ],
  "Eyzaguirre 782|Santiago": [
    -33.452094,
    -70.646198
  ],
  "Nicasio Retamales 048 058|Estación Central": [
    -33.451417,
    -70.689933
  ],
  "Av. Portugal 941|Santiago": [
    -33.454491,
    -70.633831
  ],
  "Rosas 2999|Santiago": [
    -33.437076,
    -70.676732
  ],
  "Av. María Rozas Velásquez 65|Estación Central": [
    -33.453459,
    -70.705757
  ],
  "Domingo Sta. María 2565|Independencia": [
    -33.416036,
    -70.660729
  ],
  "Toro Mazotte 76|Estación Central": [
    -33.455381,
    -70.691517
  ],
  "Leonidas Valenzuela 1270|Valparaíso": null,
  "Juan de Barros 3885|Quinta Normal": [
    -33.431414,
    -70.685782
  ],
  "Padre José Cifuentes Grez 864|Independencia": [
    -33.42217,
    -70.661365
  ],
  "Av. Lo Espejo 01173|La Cisterna": [
    -33.540178,
    -70.682562
  ],
  "Sta Clara 360|La Cisterna": [
    -33.520314,
    -70.655404
  ],
  "San Isidro 96|Santiago": [
    -33.444524,
    -70.644331
  ],
  "Av. José Joaquín Pérez 9580|Pudahuel": [
    -33.424405,
    -70.775939
  ],
  "Barros Arana 408|San Bernardo": [
    -33.593373,
    -70.698706
  ],
  "Zañartu 1100|Ñuñoa": [
    -33.472505,
    -70.60432
  ],
  "Conde del Maule 4642|Estación Central": [
    -33.45525,
    -70.700533
  ],
  "San Francisco 242|Santiago": [
    -33.454472,
    -70.646346
  ],
  "Gamero 1541|Independencia": [
    -33.420859,
    -70.658517
  ],
  "Coronel Godoy 0128|Estación Central": [
    -33.452822,
    -70.694282
  ],
  "Alcalde Pedro Alarcón 851|San Miguel": [
    -33.48704,
    -70.645294
  ],
  "San Gumercindo 77|Estación Central": [
    -33.451418,
    -70.694941
  ],
  "Gral Gana 1379|Santiago": [
    -33.456605,
    -70.718986
  ],
  "Coquimbo 56|Santiago": [
    -33.453429,
    -70.631178
  ],
  "Cuarta Avenida 1175|San Miguel": [
    -33.507022,
    -70.657677
  ],
  "San Nicolás 950|San Miguel": [
    -33.500454,
    -70.649373
  ],
  "General Mackenna 1555|Santiago": [
    -33.432899,
    -70.659806
  ],
  "Av. Departamental 915|San Miguel": [
    -33.504593,
    -70.649759
  ],
  "Calle San Ignacio de Loyola 1498|Santiago": [
    -33.363818,
    -70.755046
  ],
  "Tercera Avenida 1181|San Miguel": [
    -33.506017,
    -70.657327
  ],
  "Sta. Elena 962|Santiago": [
    -33.454316,
    -70.631563
  ],
  "Sta. Petronila 32|Estación Central": [
    -33.453957,
    -70.704907
  ],
  "Carmen 616|Santiago": [
    -33.45149,
    -70.641012
  ],
  "Arturo Prat 1312|Santiago": [
    -33.462601,
    -70.646994
  ],
  "Vicuña Mackenna 563|Santiago": [
    -33.546946,
    -70.625503
  ],
  "Vicuña Mackenna Oriente 7492|La Florida": [
    -33.517469,
    -70.595746
  ],
  "Escanilla 255|Independencia": [
    -33.42925,
    -70.65803
  ],
  "Curiñanca 920|San Miguel": [
    -33.489453,
    -70.648039
  ],
  "Buzo Sobenes 4650|Estación Central": [
    -33.450172,
    -70.698273
  ],
  "Santa Ana 79|La Granja": [
    -33.525443,
    -70.63354
  ],
  "Santa Elena 1722|Santiago": [
    -33.466561,
    -70.628045
  ],
  "María Rozas Velásquez 61|Estación Central": [
    -33.453775,
    -70.705709
  ],
  "Av. Rondizzoni 2030|Santiago": [
    -33.470318,
    -70.661045
  ],
  "C. Venecia 1635|Independencia": [
    -33.407792,
    -70.663312
  ],
  "Maipú 1644|Concepción": [
    -33.514778,
    -70.792666
  ],
  "Los Olmos 3031|Macul": [
    -33.47976,
    -70.600859
  ],
  "Linares 1415|Providencia": [
    -33.437451,
    -70.615279
  ],
  "Zañartu 2560|Ñuñoa": [
    -33.472505,
    -70.60432
  ],
  "Vicuña mackenna 1385|Santiago": [
    -33.460598,
    -70.629569
  ],
  "Esmeralda 6454|La Cisterna": [
    -33.516618,
    -70.656084
  ],
  "Colón 6435|La Cisterna": [
    -33.525349,
    -70.670699
  ],
  "Padre Orellana 1656|Santiago": [
    -33.465938,
    -70.629783
  ],
  "Eyzaguirre 819|Santiago": [
    -33.452013,
    -70.64705
  ],
  "Vicuña Mackenna 698|La Cisterna": [
    -33.544812,
    -70.652614
  ],
  "Coronel Souper 4515|Estación Central": [
    -33.458409,
    -70.696991
  ],
  "San Francisco 228|Santiago": [
    -33.456096,
    -70.645971
  ],
  "Vicuña Mackenna 327|Santiago": [
    -33.547154,
    -70.628761
  ],
  "Av. Departamental 927|San Miguel": [
    -33.504468,
    -70.650329
  ],
  "Santa Elena 1631|Santiago": [
    -33.465613,
    -70.628501
  ],
  "Chañarcillo 831|Copiapó": null,
  "Dieciocho 747|Santiago": [
    -33.455373,
    -70.656542
  ],
  "Santa Elena 898|Santiago": [
    -33.453336,
    -70.63192
  ],
  "Diag. Vicuña Mackenna 2004|Santiago": [
    -33.470273,
    -70.626344
  ],
  "Lord Cochrane 173|Santiago": [
    -33.44837,
    -70.655019
  ],
  "Hipódromo Chile 1673|Independencia": [
    -33.406484,
    -70.663547
  ],
  "Rupanco 395|La Florida": [
    -33.520694,
    -70.608748
  ],
  "Manuel Antonio Tocornal 601|Santiago": [
    -33.450524,
    -70.640094
  ],
  "Aldunate 1525|Santiago": [
    -33.466983,
    -70.653705
  ],
  "Sazie 2547|Santiago": [
    -33.451876,
    -70.671522
  ],
  "Lord Cochrane 309|Santiago": [
    -33.450568,
    -70.654989
  ],
  "Fray Camilo Henríquez 650|Santiago": [
    -33.450112,
    -70.633218
  ],
  "Fray Camilo Henríquez 660|Santiago": [
    -33.450545,
    -70.633392
  ],
  "Primera Avenida 1510|San Miguel": [
    -33.502688,
    -70.662175
  ],
  "Carrión 1507|Independencia": [
    -33.419314,
    -70.660755
  ],
  "Santa Elena 840|Santiago": [
    -33.452902,
    -70.632044
  ],
  "Chile - España 8184|La Cisterna": [
    -33.524725,
    -70.671919
  ],
  "Vicuña Mackenna 7735|La Florida": [
    -33.525703,
    -70.597375
  ],
  "Av. Fernández Albano 424|La Cisterna": [
    -33.524968,
    -70.652817
  ],
  "Vicuña Mackenna 2935|San Joaquín": [
    -33.477181,
    -70.622898
  ],
  "Vicuña Mackenna 2289|San Joaquín": [
    -33.471409,
    -70.624233
  ],
  "Alcalde Pedro Alarcón 834|San Miguel": [
    -33.487302,
    -70.644897
  ],
  "General Prieto 1305|Independencia": [
    -33.429934,
    -70.65446
  ],
  "Portales 2895|Santiago": [
    -33.44292,
    -70.675306
  ],
  "Septima Avenida 1330|San Miguel": [
    -33.509197,
    -70.661843
  ],
  "Lira 570|Santiago": [
    -33.449899,
    -70.638699
  ],
  "Mujica 99|Ñuñoa": [
    -33.450997,
    -70.629817
  ],
  "Nicasio Retamales 048|Estación Central": [
    -33.460375,
    -70.687953
  ],
  "Alcalde Pedro Alarcón 805|San Miguel": [
    -33.487287,
    -70.644052
  ],
  "María Rozas Velásquez 51|Estación Central": [
    -33.454423,
    -70.705622
  ],
  "Alcalde Pedro Alarcon 844|San Miguel": [
    -33.487249,
    -70.645167
  ],
  "Cnel. Souper 4515|Estación Central": null,
  "Av. Lib. Bernado O'Higgins 4103|Estación Central": null,
  "Av. María 6415|La Cisterna": [
    -33.517219,
    -70.651711
  ],
  "Francisco de Villagra 268|Ñuñoa": [
    -33.454255,
    -70.575298
  ],
  "Av. Buzeta 4460|Cerrillos": [
    -33.482037,
    -70.692813
  ],
  "Av. Portugal 910|Santiago": [
    -33.454088,
    -70.633695
  ],
  "Blanco Encalada 2007|Santiago": [
    -33.456572,
    -70.66275
  ],
  "Sta Elena 895|Santiago": [
    -33.453365,
    -70.63205
  ],
  "Fray Camilo Henríquez 463|Santiago": [
    -33.447555,
    -70.634616
  ],
  "Av. Ossa 375|La Cisterna": [
    -33.540001,
    -70.659466
  ],
  "Blanco Garcés 154|Estación Central": [
    -33.45036,
    -70.698004
  ],
  "Carmen Mena 1050|San Miguel": [
    -33.506501,
    -70.654669
  ],
  "Lord Cochrane 136|Santiago": [
    -33.45363,
    -70.654163
  ],
  "Lago Ranco 1890|Pedro Aguirre Cerda": [
    -33.483817,
    -70.663031
  ],
  "Vergara 583|Santiago": [
    -33.454323,
    -70.661613
  ],
  "Tarapacá 890|Santiago": [
    -33.447602,
    -70.652317
  ],
  "Vicuña Mackenna 2004|Santiago": [
    -33.468461,
    -70.625938
  ],
  "Franklin 312|Santiago": [
    -33.471813,
    -70.629642
  ],
  "Rosas 1339|Santiago": [
    -33.435452,
    -70.656344
  ],
  "Av. Quilín 107|Macul": [
    -33.488182,
    -70.583815
  ],
  "Sta. Isabel 77|Santiago": [
    -33.44758,
    -70.633229
  ],
  "Chiloe 1221|Santiago": [
    -33.461227,
    -70.646286
  ],
  "Zañartu 2132|Ñuñoa": [
    -33.472448,
    -70.610356
  ],
  "Sta. Petronila 38|Estación Central": [
    -33.453637,
    -70.70495
  ],
  "Gral. Jofré 67|Santiago": null,
  "Zañartu 980|Ñuñoa": [
    -33.472505,
    -70.60432
  ],
  "Castillo Urizar 1845|Ñuñoa": [
    -33.471981,
    -70.610398
  ],
  "Las Enredaderas 2118|Independencia": [
    -33.40624,
    -70.668479
  ],
  "Eyzaguirre 771|Santiago": [
    -33.451885,
    -70.646145
  ],
  "Juan Mitjans 105|Macul": [
    -33.478084,
    -70.621054
  ],
  "Mujica 55|Ñuñoa": [
    -33.451124,
    -70.630301
  ],
  "Froilán Roa 5746|La Florida": [
    -33.5099,
    -70.602007
  ],
  "Av. Departamental 1475|La Florida": [
    -33.508885,
    -70.610998
  ],
  "Segunda Avenida 1245|San Miguel": [
    -33.504678,
    -70.658174
  ],
  "San Pablo 1539|Santiago": [
    -33.434449,
    -70.659462
  ],
  "Milán 1242|San Miguel": [
    -33.477513,
    -70.648911
  ],
  "Av. Los Pajaritos 464|Maipú": [
    -33.522796,
    -70.757404
  ],
  "Blanco Encalada 1771|Santiago": [
    -33.500328,
    -70.766475
  ],
  "Eleuterio Ramírez 1070|Santiago": [
    -33.449397,
    -70.650443
  ],
  "Carlos Silva Vildósola 870|San Miguel": [
    -33.477954,
    -70.644075
  ],
  "Vicuña Mackenna 601|Santiago": [
    -33.449066,
    -70.631907
  ],
  "Tarapacá 876|Santiago": [
    -33.447602,
    -70.652317
  ],
  "Ascotán Nte. 155|Antofagasta": null,
  "Sta. Elena 1342|Santiago": [
    -33.470775,
    -70.626946
  ],
  "Av. Vicuña Mackenna 2289|San Joaquín": [
    -33.471409,
    -70.624233
  ],
  "Carlos Pezoa Véliz 143|Estación Central": [
    -33.455067,
    -70.70314
  ],
  "Av. Irarrázaval 2220|Ñuñoa": [
    -33.453453,
    -70.607997
  ],
  "Coronel Godoy 149|Estación Central": [
    -33.456819,
    -70.692968
  ],
  "Av. María Rozas Velásquez 45|Estación Central": [
    -33.452419,
    -70.706155
  ],
  "Trinidad Ramírez 1010|La Cisterna": [
    -33.538986,
    -70.682341
  ],
  "Sta Victoria 540|Santiago": [
    -33.448955,
    -70.642578
  ],
  "Emilio Vaisse 770|Ñuñoa": [
    -33.451393,
    -70.625848
  ],
  "Santiago 1355|Santiago": [
    -33.462483,
    -70.652328
  ],
  "Av. Costanera del Rio Sur 1201|La Serena": null,
  "Belisario Prats 1850|Independencia": [
    -33.409707,
    -70.655169
  ],
  "Libertad 30|Maipú": [
    -33.50562,
    -70.757871
  ],
  "Nueva Cuatro 6277|La Florida": [
    -33.510793,
    -70.595845
  ],
  "Manuel Antonio Tocornal 588|Santiago": [
    -33.450371,
    -70.639963
  ],
  "Los Alerces 2660|Ñuñoa": [
    -33.486757,
    -70.60557
  ],
  "Placilla 046|Estación Central": [
    -33.453964,
    -70.695163
  ],
  "Merced 562|Santiago": [
    -33.438039,
    -70.644544
  ],
  "Lord Cochrane 635|Santiago": [
    -33.453904,
    -70.654294
  ],
  "Amunátegui 620|Santiago": [
    -33.436505,
    -70.657203
  ],
  "Nataniel Cox 683|Santiago": [
    -33.454266,
    -70.652599
  ],
  "San Martín 733|Santiago": [
    -33.435346,
    -70.658536
  ],
  "Abtao 24|Estación Central": [
    -33.452981,
    -70.700464
  ],
  "Chacabuco 1355|Santiago": [
    -33.429539,
    -70.679609
  ],
  "Av. Lo Ovalle 150|La Cisterna": [
    -33.514193,
    -70.659997
  ],
  "Conde del Maule 4577|Estación Central": [
    -33.454124,
    -70.698854
  ],
  "Vicuña Mackenna 1385|Santiago": [
    -33.460598,
    -70.629569
  ],
  "Matta Oriente 849|Ñuñoa": [
    -33.454131,
    -70.62215
  ],
  "Arturo Prat 644|Santiago": [
    -33.45311,
    -70.648388
  ],
  "Walker Martínez 1100|La Florida": [
    -33.522473,
    -70.586635
  ],
  "Huerfanos 1761|Santiago": [
    -33.440659,
    -70.661825
  ],
  "Av. Sta. Rosa 991|Santiago": [
    -33.456808,
    -70.643783
  ],
  "Santa Victoria 366|Santiago": [
    -33.447974,
    -70.638344
  ],
  "Vicuña Mackenna 6130|La Florida": [
    -33.559364,
    -70.587749
  ],
  "Nelson 1816|Ñuñoa": [
    -33.471509,
    -70.608095
  ],
  "Av. El Parrón 103 113|La Cisterna": [
    -33.522562,
    -70.672468
  ],
  "Walker Martínez 3142|La Florida": [
    -33.522079,
    -70.564345
  ],
  "Av. Goycolea 420|La Cisterna": [
    -33.538394,
    -70.671106
  ],
  "Carlos Silva Vildósola 1068|San Miguel": [
    -33.477639,
    -70.648229
  ],
  "Sargento Aldea 1156|Santiago": [
    -33.468782,
    -70.649082
  ],
  "Emilio Vaisse 760|Ñuñoa": [
    -33.450975,
    -70.625975
  ],
  "Arturo Prat 636|Santiago": [
    -33.453022,
    -70.648405
  ],
  "Catedral 1757|Santiago": [
    -33.438391,
    -70.661708
  ],
  "Serrano 633|Santiago": [
    -33.452871,
    -70.647839
  ],
  "Colombia 7664|La Florida": [
    -33.525057,
    -70.589099
  ],
  "Av. Sta. Rosa 537|Santiago": [
    -33.451053,
    -70.644687
  ],
  "La Coruña 4890|Estación Central": [
    -33.452422,
    -70.701839
  ],
  "Lord Cochrane 1431|Santiago": [
    -33.465131,
    -70.652857
  ],
  "Cnel. Souper 4171|Estación Central": null,
  "Av. Libertador Bernardo O'Higgins 4361|Estación Central": [
    -33.454477,
    -70.695636
  ],
  "Argomedo 350|Santiago": [
    -33.449912,
    -70.636526
  ],
  "Ventura Blanco Viel 1377|San Miguel": [
    -33.494932,
    -70.65909
  ],
  "Av. España 471|Santiago": [
    -33.454709,
    -70.669528
  ],
  "Novena Avenida 1316|San Miguel": [
    -33.51108,
    -70.663009
  ],
  "Av. El Parrón 103|La Cisterna": [
    -33.526031,
    -70.662401
  ],
  "Av. Vicuña Mackenna 1290|Ñuñoa": [
    -33.45601,
    -70.629587
  ],
  "Alcalde Pedro Alarcon 875|San Miguel": [
    -33.48605,
    -70.65046
  ],
  "C. Uno 6590|La Cisterna": [
    -33.513697,
    -70.669394
  ],
  "Domeyko 2505|Santiago": [
    -33.455824,
    -70.661961
  ],
  "Av. Quilín 123|Macul": [
    -33.485263,
    -70.597906
  ],
  "Lazo 1365|San Miguel": [
    -33.49849,
    -70.660044
  ],
  "Raulí 596|Santiago": [
    -33.448056,
    -70.636892
  ],
  "Alcalde Pedro Alarcón 921|San Miguel": [
    -33.486639,
    -70.647308
  ],
  "Blanco Encalada 2527|Santiago": [
    -33.500328,
    -70.766475
  ],
  "Lazo 1420|San Miguel": [
    -33.498286,
    -70.661277
  ],
  "Portugal 810|Santiago": [
    -33.452863,
    -70.634019
  ],
  "Vicuña Mackenna 692|Ñuñoa": [
    -33.451281,
    -70.630696
  ],
  "Av Macul 3700|Macul": [
    -33.488073,
    -70.599316
  ],
  "General Bulnes 158|Santiago": [
    -33.443508,
    -70.669904
  ],
  "Coquimbo 14|Santiago": [
    -33.453458,
    -70.630962
  ],
  "Toesca 2597|Santiago": [
    -33.455317,
    -70.671508
  ]
};
